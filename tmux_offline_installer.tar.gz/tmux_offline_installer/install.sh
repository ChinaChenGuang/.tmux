#!/bin/bash
set -e

TMUX_DIR="$HOME/.tmux"
TMUX_CONF="$HOME/.tmux.conf"
BACKUP_SUFFIX="_backup_$(date +%Y%m%d_%H%M%S)"

echo "Installing tmux configuration..."

# Backup existing config
if [ -d "$TMUX_DIR" ]; then
    echo "Backing up existing $TMUX_DIR to ${TMUX_DIR}${BACKUP_SUFFIX}"
    mv "$TMUX_DIR" "${TMUX_DIR}${BACKUP_SUFFIX}"
fi

if [ -f "$TMUX_CONF" ] && [ ! -L "$TMUX_CONF" ]; then
    echo "Backing up existing $TMUX_CONF to ${TMUX_CONF}${BACKUP_SUFFIX}"
    mv "$TMUX_CONF" "${TMUX_CONF}${BACKUP_SUFFIX}"
fi

if [ -L "$TMUX_CONF" ]; then
    echo "Removing existing symlink $TMUX_CONF"
    rm "$TMUX_CONF"
fi

# Install new config
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "Copying configuration to $TMUX_DIR..."
cp -r "$SCRIPT_DIR/dot_tmux" "$TMUX_DIR"

# Create symlink
echo "Creating symlink for .tmux.conf..."
ln -s "$TMUX_DIR/.tmux.conf" "$TMUX_CONF"

echo "Installation complete."
echo "If tmux is running, reload it with: tmux source-file ~/.tmux.conf"
