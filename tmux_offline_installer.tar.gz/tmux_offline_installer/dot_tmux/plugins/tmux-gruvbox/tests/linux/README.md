# Linux tests

Those tests are meant to run on linux:

- ubuntu 20.04 LTS
- with bash
